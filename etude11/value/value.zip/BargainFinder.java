package value;

import java.util.*;

/**
 * The class for bargain finders.
 * 
 * @author MichaelAlbert
 */
public class BargainFinder {
    
    private SiteInfo site;
    private CustomerInfo customer;
    private int budget;

    private List<String> cart;

    public BargainFinder(SiteInfo site, CustomerInfo customer, int budget) {
        this.site = site;
        this.customer = customer;
        this.budget = budget;
    }
    
    public ArrayList<String> shoppingList() {
    	ArrayList<String> items = customer.getItems();
        //Tree<String> root = new Tree<String>("");
        //return delve(root, items);
        return items;
    }
/**
    public static ArrayList<String> delve(String input, ArrayList<String> itemList){
        cart = input.pastList;
        for (String s : itemList){
           cart.add(s);
           if (site.getCost(cart) <= budget){
                cart.remove(s);
                Tree<String> next = new Tree<String>(s);
           }
        }
    }
*/
}
